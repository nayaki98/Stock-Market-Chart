package com.example.stockspring.controller;

public class RestControllerStockExchange {

}
