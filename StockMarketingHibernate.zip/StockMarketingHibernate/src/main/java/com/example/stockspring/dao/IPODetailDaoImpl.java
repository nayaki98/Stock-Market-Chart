package com.example.stockspring.dao;

import java.sql.SQLException;

import com.example.stockspring.model.IPODetail;


