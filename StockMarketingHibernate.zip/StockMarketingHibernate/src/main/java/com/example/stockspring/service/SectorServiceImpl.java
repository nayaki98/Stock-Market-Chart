package com.example.stockspring.service;

public class SectorServiceImpl {

}
