package com.example.stockspring.service;

public interface SectorService {

}
