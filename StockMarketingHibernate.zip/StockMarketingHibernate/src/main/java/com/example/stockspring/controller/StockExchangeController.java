package com.example.stockspring.controller;

public interface StockExchangeController {

}
