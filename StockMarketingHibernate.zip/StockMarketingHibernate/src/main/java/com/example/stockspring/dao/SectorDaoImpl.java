package com.example.stockspring.dao;

public class SectorDaoImpl {

}
