package com.example.stockspring.controller;

import com.example.stockspring.model.User;

public interface UserController {
	

}
